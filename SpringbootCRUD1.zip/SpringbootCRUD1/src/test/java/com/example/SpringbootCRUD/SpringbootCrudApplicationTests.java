package com.example.SpringbootCRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
