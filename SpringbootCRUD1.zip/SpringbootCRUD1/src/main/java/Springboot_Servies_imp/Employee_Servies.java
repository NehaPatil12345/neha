package Springboot_Servies_imp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Springboot_Repository.Employee_Repository;
import Springboot_Servies.Employee_Servies1;
import Springboot_model.Employee;


@Service
public class Employee_Servies implements Employee_Servies1 {

	
	@Autowired
	private Employee_Repository empRepo;
	
	@Override
	public Employee addEmployee(Employee employee) {
	Employee emp = empRepo.save(employee);
		return emp;
	}

	@Override
	public String removeEmployee(int id) {
		empRepo.deleteById(id);
		return "Deleted data successfully";
	}

	@Override
	public Optional<Employee> findEmpById(int id) {
		
		Optional<Employee> emp = empRepo.findById(id);
		
		if(emp.isPresent()) {
			return emp;
		}else {
			return null;
		}
	}

	@Override
	public List<Employee> getAllEmployee() {
		List<Employee> empList = empRepo.findAll();
		
		return empList;
	}

	@Override
	public String updateEmployee(int id) {
		Optional<Employee> emp = empRepo.findById(id);
		
		if(emp.isPresent()) {
			Employee emps = new Employee();
			
			empRepo.save(emps);
			return "Updated Successfully";
		}else {
			return "Employee Not Found";
		}
		
	}
	
}
