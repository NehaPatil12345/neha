package Springboot_Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Springboot_model.Employee;

public interface Employee_Repository extends JpaRepository<Employee, Integer>{
}
