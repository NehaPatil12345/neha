package Springboot_model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;



	@Entity
	@Table(name="employee_master")
	public class Employee {

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private long Employee_ID;
		
		@Column(name="First_Name")
		private String First_Name;

		@Column(name="Last_Name")
		private String Last_Name;
		
		@Column(name="Date_of_Birth")
		private String Date_of_Birth;
		
		@Column(name="Nationality")
		private String Nationality;
		
		@Column(name="Address")
		private String Address;
		
		@Column(name="Contact_Number")
		private int Contact_Number;
		
		@Column(name="Department")
		private String Department;
		
		@Column(name="Job_title")
		private String Job_title;
		
		public Employee()
		{
			super();
		}
		
		
		public Employee(long employee_ID, String first_Name, String last_Name, String date_of_Birth, String nationality,
				String address, int contact_Number, String department, String job_title)
		
		{
			super();
			Employee_ID = employee_ID;
			First_Name = first_Name;
			Last_Name = last_Name;
			Date_of_Birth = date_of_Birth;
			Nationality = nationality;
			Address = address;
			Contact_Number = contact_Number;
			Department = department;
			Job_title = Job_title;
		}
		

		public long getEmployee_ID() {
			return Employee_ID;
		}

		public void setEmployee_ID(long employee_ID) {
			Employee_ID = employee_ID;
		}

		public String getFirst_Name() {
			return First_Name;
		}

		public void setFirst_Name(String first_Name) {
			First_Name = first_Name;
		}

		public String getLast_Name() {
			return Last_Name;
		}

		public void setLast_Name(String last_Name) {
			Last_Name = last_Name;
		}

		public String getDate_of_Birth() {
			return Date_of_Birth;
		}

		public void setDate_of_Birth(String date_of_Birth) {
			Date_of_Birth = date_of_Birth;
		}

		public String getNationality() {
			return Nationality;
		}

		public void setNationality(String nationality) {
			Nationality = nationality;
		}

		public String getAddress() {
			return Address;
		}

		public void setAddress(String address) {
			Address = address;
		}

		public int getContact_Number() {
			return Contact_Number;
		}

		public void setContact_Number(int contact_Number) {
			Contact_Number = contact_Number;
		}

		public String getDepartment() {
			return Department;
		}

		public void setDepartment(String department) {
			Department = department;
		}

		public String getJob_title() {
			return Job_title;
		}

		public void setJob_title(String job_title) {
			Job_title = job_title;
		}
		
		
		}

